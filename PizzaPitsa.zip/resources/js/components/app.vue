<template>
    <MainVue/>
</template>

<script>
import MainVue from './frontend/pages/Main.vue';

export default{
  components:{MainVue},
}
</script>