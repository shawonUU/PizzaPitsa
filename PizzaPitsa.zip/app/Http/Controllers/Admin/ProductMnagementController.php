<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ProductMnagementController extends Controller
{
    public function  category(Request $request){
        return "okk";
    }
}
