<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Pizza Pitso</title>
        <link rel="preconnect" href="https://fonts.bunny.net">
         <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/css/vendor/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/css/vendor/font-awesome.css">
        <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/css/vendor/flaticon/flaticon.css">
        <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/css/vendor/slick.css">
        <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/css/vendor/slick-theme.css">
        <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/css/vendor/jquery-ui.min.css">
        <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/css/vendor/sal.css">
        <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/css/vendor/magnific-popup.css">
        <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/css/vendor/base.css">
        <link rel="stylesheet" href="<?php echo e(asset('frontend')); ?>/assets/css/style.min.css">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />       
    </head>
    <body class="sticky-header">
        <div id="app"></div>
        <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
          <!-- JS
============================================ -->
    <!-- Modernizer JS -->
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/vendor/modernizr.min.js"></script>
    <!-- jQuery JS -->
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/vendor/jquery.js"></script>
    <!-- Bootstrap JS -->
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/vendor/popper.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/vendor/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/vendor/slick.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/vendor/js.cookie.js"></script>
    <!-- <script src="assets/js/vendor/jquery.style.switcher.js"></script> -->
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/vendor/jquery-ui.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/vendor/jquery.ui.touch-punch.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/vendor/jquery.countdown.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/vendor/sal.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/vendor/jquery.magnific-popup.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/vendor/imagesloaded.pkgd.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/vendor/isotope.pkgd.min.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/vendor/counterup.js"></script>
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/vendor/waypoints.min.js"></script>

    <!-- Main JS -->
    <script src="<?php echo e(asset('frontend')); ?>/assets/js/main.js"></script>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\PizzaPitsa\resources\views/frontend/layouts/app.blade.php ENDPATH**/ ?>