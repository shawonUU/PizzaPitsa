<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>document.write(new Date().getFullYear())</script> © Pizza Pitsa.
            </div>            
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\PizzaPitsa\resources\views/admin/layout/footer.blade.php ENDPATH**/ ?>