<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SizeVsTopingPrice extends Model
{
    use HasFactory;
    protected $table = "size_vs_toping_price";
}
