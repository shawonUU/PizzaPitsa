<template>
    <div>
        <main class="main-wrapper">
        <!-- Start Breadcrumb Area  -->
        <div class="axil-breadcrumb-area">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-md-8">
                        <div class="inner">
                            <ul class="axil-breadcrumb">
                                <li class="axil-breadcrumb-item"><router-link to="/">Home</router-link></li>
                                <li class="separator"></li>
                                <li class="axil-breadcrumb-item active" aria-current="page">About Us</li>
                            </ul>
                            <h1 class="title">About Our Store</h1>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-4">
                        <div class="inner">
                            <div class="bradcrumb-thumb">
                                <img src="https://new.axilthemes.com/demo/template/etrade-rtl/assets/images/product/product-45.png" alt="Image">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Breadcrumb Area  -->

        <!-- Start About Area  -->
        <div class="axil-about-area about-style-1 axil-section-gap ">
            <div class="container">
                <div class="row align-items-center">
                    
                    <div class="col-xl-12 col-lg-6">
                        <div class="about-content content-right">
                            <span class="title-highlighter highlighter-primary2"> <i class="far fa-shopping-basket"></i>About Store</span>
                            <h3 class="title">Welcome to Pizza Pitsa: Where Passion and Quality Meet</h3>
                            <span class="text-heading">In the heart of Finland, a new culinary sensation has emerged, captivating the palates of pizza enthusiasts and aficionados alike. Born in December 2023, Pizza Pitsa is a Finnish franchise pizza chain restaurant dedicated to crafting the perfect pizza experience. At Pizza Pitsa, we infuse every slice with our love for great food, ensuring that each bite is a celebration of flavor, freshness, and authenticity.</span>
                            <div class="row">
                                <div class="col-xl-6">
                                    <p class="text-heading" >Quality Ingredients:
                                    Central to the Pizza Pitsa philosophy is our unwavering commitment to using only the finest ingredients. From the moment our journey began, we set out to source the freshest produce, the most succulent meats, and the most flavorful cheeses. Our dedication to quality means that every pizza we serve is a masterpiece of taste and texture, a symphony of flavors that dance harmoniously on the palate.
                                    </p>
                                </div>
                                <div class="col-xl-6">
                                    <p  class="mb--0 text-heading">Customer Service Excellence:
                                    At Pizza Pitsa, we understand that great food is only part of the equation. That's why we go above and beyond to deliver an unparalleled customer experience. From the moment you walk through our doors, you'll be greeted with a warm smile and a friendly welcome. Our dedicated team is here to ensure that your dining experience is nothing short of extraordinary, catering to your every need with professionalism and courtesy.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End About Area  -->

        <!-- Start About Area  -->
        <div class="about-info-area">
            <div class="container">
                <div class="row row--20">
                    <div class="col-lg-4">
                        <div class="about-info-box">
                            
                            <div class="content">
                                <h6 class="title">Hygiene is Our Priority:</h6>
                                <p class="text-heading" style="font-size:15px">
                                    In today's world, hygiene has never been more important. That's why, at Pizza Pitsa, we take cleanliness and sanitation seriously. From our kitchen to our dining area, every corner of our restaurant is meticulously maintained to the highest standards of hygiene. We adhere to strict cleaning protocols and undergo regular inspections to ensure that our facilities are pristine and germ-free. When you dine at Pizza Pitsa, you can rest assured that your health and safety are our top priorities.
                                    <br>
                                    <br>
                                    </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="about-info-box">                          
                            <div class="content">
                                <h6 class="title">A Menu to Delight Every Palate:</h6>
                                <p class="text-heading" style="font-size:15px">At Pizza Pitsa, we believe that variety is the spice of life. That's why we offer a diverse menu featuring a wide range of pizza creations to suit every taste and preference. Whether you're a fan of classic Margherita, a lover of fiery pepperoni, or craving something adventurous like our signature Mumbai and BBQ chicken pizza, we have something for everyone. And for those with dietary restrictions or special preferences, we offer customizable options to ensure that everyone can enjoy a delicious meal at Pizza Pitsa.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="about-info-box">                            
                            <div class="content">
                                <h6 class="title">Community and Sustainability:</h6>
                                <p class="text-heading" style="font-size:15px">
                                    At Pizza Pitsa, we believe in giving back to the communities that support us. That's why we're committed to sourcing our ingredients locally whenever possible, supporting local farmers and producers while reducing our carbon footprint. We also strive to minimize waste and promote sustainability in every aspect of our operations, from energy-efficient practices to eco-friendly packaging. By working together with our community, we're not just serving great food – we're building a better, more sustainable future for everyone.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End About Area  -->

      

        <!-- Start About Area  -->
        <div class="axil-about-area about-style-2">
            <div class="container">
                <div class="row align-items-center mb--80 mb_sm--60">                   
                    <div class="col-lg-7 m-auto">
                        <div class="about-content content-right">                           
                            <h4 class="title">Join Us at Pizza Pitsa:</h4>
                            <p class="text-heading">Whether you're dining in with family and friends, grabbing a quick slice on the go, or hosting a special event, Pizza Pitsa is the perfect destination for pizza lovers everywhere. With our unwavering dedication to quality, service, and hygiene, we're proud to be Finland's premier pizza destination. Come experience the magic of Pizza Pitsa for yourself and taste the difference that passion and quality can make. We can't wait to welcome you into the Pizza Pitsa family!</p>
                            <router-link to="/contact" class="axil-btn btn-outline">Get In Touch</router-link>
                        </div>
                    </div>
                </div>            
            </div>
        </div>
        <!-- End About Area  -->
    </main>
    </div>
</template>