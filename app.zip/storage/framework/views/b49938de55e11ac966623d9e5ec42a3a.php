<!-- pin_code_email.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your PIN Code</title>
</head>
<body>
    <p>Your verification code is: <?php echo e($pinCode); ?></p>
    <p>Please use this code for authentication purposes.</p>
</body>
</html>
<?php /**PATH E:\laragon\www\lb_old\resources\views/layouts/verificationMail.blade.php ENDPATH**/ ?>