

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">

            <div class="row">
                <div class="col">
                    <div class="card p-3">
                        <form action="<?php echo e(route('coupons.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-12 col-md-6 col-lg-4">
                                    <label for="code" class="form-label">Coupon Code</label>
                                    <input type="text" class="form-control" id="code" name="code" placeholder="Coupon Code">
                                </div>

                                <div class="col-12 col-md-6 col-lg-4">
                                    <label for="discount" class="form-label">Discount</label>
                                    <input type="text" class="form-control" id="discount" name="discount" placeholder="Discount">
                                </div>

                                <div class="col-12 col-md-6 col-lg-4">
                                    <label for="is_percentage" class="form-label">Discount Type</label>
                                    <select class="form-control" id="discount_type" name="discount_type">
                                        <?php $__currentLoopData = getAmountType(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>" <?php echo e($key == 1 ? 'selected' : ''); ?>><?php echo e($type); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="col-12 col-md-6 col-lg-4">
                                    <label for="quantity" class="form-label">Quantity</label>
                                    <input type="number" class="form-control" id="quantity" name="quantity" placeholder="Quantity">
                                </div>

                                <div class="col-12 col-md-6 col-lg-4">
                                    <label for="expires_at" class="form-label">Expires At</label>
                                    <input type="datetime-local" class="form-control" id="expires_at" name="expires_at">
                                </div>
                                <div class="col-12 col-md-6 col-lg-4">
                                    <label for="basiInput" class="form-label">Status</label>
                                    <select name="status" id="" class="form-control">
                                        <?php $__currentLoopData = getStatus(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <option value="<?php echo e($key); ?>" <?php echo e($key == 1 ? 'selected' : ''); ?>><?php echo e($status); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="d-flex flex-row-reverse bd-highlight">
                                    <button type="submit" class="btn btn-primary mt-1">Add Coupon</button>
                                </div>
                            </div>
                        </form>

                        <div class="card-header align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">Category List</h4>
                        </div>

                        <div class="card-body">
                            <table class="table table-stripedw-100">
                                <thead>
                                    <tr>
                                        <th scope="col">Id</th>
                                        <th scope="col">Coupon Code</th>
                                        <th scope="col">Discount</th>
                                        <th scope="col">Discount Type</th>
                                        <th scope="col">Quantity</th>
                                        <th scope="col">Expires At</th>
                                        <th scope="col">Status</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($loop->index+1); ?></th>
                                        <td><?php echo e($coupon->code); ?></td>
                                        <td><?php echo e($coupon->discount); ?></td>
                                        <td><?php echo e(getAmountType()[$coupon->discount_type]); ?></td>
                                        <td><?php echo e($coupon->quantity); ?></td>
                                        <td><?php echo e($coupon->expires_at); ?></td>
                                        <td><?php echo e(getStatus()[$coupon->status]); ?></td>
                                        <td>
                                            <button class="btn btn-sm btn-primary" title="Edit" data-bs-toggle="modal" data-bs-target="#ctegory<?php echo e($coupon->id); ?>">
                                                <i class="bx bx-edit"></i>
                                            </button>

                                            <div id="ctegory<?php echo e($coupon->id); ?>" class="modal fade" tabindex="-1" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                            <form action="<?php echo e(route('coupons.update', $coupon->id)); ?>" method="POST">
                                                    <?php echo method_field('PUT'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title" id="myModalLabel">Add Category</h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"> </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <div class="">
                                                                    <label for="code" class="form-label">Coupon Code</label>
                                                                    <input type="text" class="form-control" id="code" name="code" value="<?php echo e($coupon->code); ?>" placeholder="Coupon Code">
                                                                </div>

                                                                <div class="">
                                                                    <label for="discount" class="form-label">Discount</label>
                                                                    <input type="text" class="form-control" id="discount" name="discount" value="<?php echo e($coupon->discount); ?>" placeholder="Discount">
                                                                </div>

                                                                <div class="">
                                                                    <label for="is_percentage" class="form-label">Discount Type</label>
                                                                    <select class="form-control" id="discount_type" name="discount_type">
                                                                        <?php $__currentLoopData = getAmountType(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($key); ?>" <?php echo e($coupon->discount_type == 1 ? 'selected' : ''); ?>><?php echo e($type); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </div>

                                                                <div class="">
                                                                    <label for="quantity" class="form-label">Quantity</label>
                                                                    <input type="number" class="form-control" id="quantity" name="quantity" value="<?php echo e($coupon->quantity); ?>" placeholder="Quantity">
                                                                </div>

                                                                <div class="">
                                                                    <label for="expires_at" class="form-label">Expires At</label>
                                                                    <input type="datetime-local" class="form-control" id="expires_at" name="expires_at" value="<?php echo e($coupon->expires_at); ?>">
                                                                </div>
                                                                <div class="">
                                                                    <label for="basiInput" class="form-label">Status</label>
                                                                    <select name="status" id="" class="form-control">
                                                                        <?php $__currentLoopData = getStatus(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                                            <option value="<?php echo e($key); ?>" <?php echo e($coupon->status == 1 ? 'selected' : ''); ?>><?php echo e($status); ?></option>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </div>
                                                                
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                                                                <button type="submit" class="btn btn-primary ">Save</button>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </form>
                                            </div>


                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lb_old\resources\views/admin/pages/product/coupon/index.blade.php ENDPATH**/ ?>