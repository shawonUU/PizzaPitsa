

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">

            

        </div>
        <!-- container-fluid -->
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lb_old\resources\views/admin/index.blade.php ENDPATH**/ ?>