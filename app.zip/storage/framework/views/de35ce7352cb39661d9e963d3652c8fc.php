
<tr>
    <td class="orderSl"></td>                                    
    <td><?php echo e($item->order_number); ?></td>                                   
    <td><?php echo e(getUser($item->customer_id)); ?></td>                                  
    <td><?php echo e($item->type =='2'?'Pickup/Dine in':'Delivery'); ?></td>                                  
    <td><?php echo e($item->total_amount); ?></td>                                  
    <td><?php echo e($item->paid_amount); ?></td>                                                                
    <td><?php echo e($item->delivery_address_id); ?></td>                                  
    <td>
        <select class="form-select rounded-pill mb-3" onchange="updateStatus('<?php echo e($item->order_number); ?>',this.value)">
            <?php $__currentLoopData = orderStatuses(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php echo e($value == $item->order_status ? 'selected' : ''); ?> value="<?php echo e($value); ?>"><?php echo e($text); ?></option> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                                                 
        </select>
    </td> 
    <td>
        <a class="btn btn-info" href="<?php echo e(route('order.details',$item->order_number)); ?>">Details</a>    
    </td>                                                                                                                                                                                              
  </tr><?php /**PATH C:\laragon\www\lb_old\resources\views/admin/pages/order/singleOrder.blade.php ENDPATH**/ ?>