

<?php $__env->startSection('content'); ?>
    <div class="page-content">
        <div class="container-fluid">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger" id="validation-error-alert">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

                <script>
                    // Set a timeout to hide the alert after 2000 milliseconds (2 seconds)
                    setTimeout(function () {
                        document.getElementById('validation-error-alert').style.display = 'none';
                    }, 3000);
                </script>
            <?php endif; ?>
            <div class="row">
                <div class="col-lg-12">
                  <div class="card">
                    <div class="card-header align-items-center d-flex">
                      <h4 class="card-title mb-0 flex-grow-1">Create User</h4>
                      <div class="flex-shrink-0">
                        <div class="form-check form-switch form-switch-right form-switch-md">
                            <a href="<?php echo e(route('users.index')); ?>" class="btn btn-info">User List</a>
                        </div>
                      </div>
                    </div>
                    <!-- end card header -->
                    <div class="card-body">
                      <div class="live-preview">
                        <div class="row gy-4">
                            <form action="<?php echo e(route('users.store')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <!-- <div class="col-xxl-3 col-md-6 mb-3">
                                        <label for="name" class="form-label">Type</label>
                                        <select class="form-select mb-3" name="role_id">
                                            <?php $__currentLoopData = userTypes(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                                                        
                                        </select>
                                    </div> -->
                                    <div class="col-xxl-3 col-md-6 mb-3">
                                        <label for="name" class="form-label">Name</label>
                                        <input type="text" class="form-control" value="<?php echo e(old('name')); ?>" id="name" name="name" placeholder="Enter User name" >
                                    </div>                                    
                                    <div class="col-xxl-3 col-md-6 mb-3">
                                        <label for="name" class="form-label">Email</label>
                                        <input type="text" class="form-control" value="<?php echo e(old('email')); ?>" id="email" name="email" placeholder="Enter User email" >
                                    </div>
                                    <div class="col-xxl-3 col-md-6 mb-3">
                                        <label for="name" class="form-label">Phone</label>
                                        <input type="text" class="form-control" value="<?php echo e(old('phone')); ?>" id="phone" name="phone" placeholder="Enter User phone" >
                                    </div>
                                    <div class="col-xxl-3 col-md-6 mb-3">
                                        <label for="name" class="form-label">Password</label>
                                        <input type="text" class="form-control" value="<?php echo e(old('password')); ?>" id="password" name="password" placeholder="Enter User password" >
                                    </div>
                                    <div class="col-xxl-3 col-md-6 mb-3">
                                        <label for="image" class="form-label">Image(366x366)</label>
                                        <input type="file" multiple class="form-control" id="image" name="images">
                                    </div>
                                    <div class="col-xxl-3 col-md-6 mb-3">
                                        <label for="status" class="form-label">Status</label>
                                        <select class="form-select mb-3" name="status">
                                            <option selected="" value="1">Actve</option>
                                            <option value="0">InActve</option>
                                        </select>
                                    </div>
                                    <div class="col-xxl-3 col-md-6 mb-3">
                                        <label for="name" class="form-label">Role</label>
                                        <select class="form-select mb-3" name="user_role" required>
                                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                                                        
                                        </select>
                                    </div>                                    
                                </div>
                                <button type="submit" class="btn btn-primary float-end">Submit</button>
                            </form>

                        </div>
                        <!--end row-->
                      </div>
                    </div>
                  </div>
                </div>
                <!--end col-->
              </div>

        </div>
        <!-- container-fluid -->
    </div>

<?php $__env->startSection('script'); ?>
<script>
    ClassicEditor
    .create(document.querySelector('#editor'))
    .catch(error => {
        console.error(error);
    });

</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\PizzaPitsa\resources\views/admin/pages/users/create.blade.php ENDPATH**/ ?>