<!DOCTYPE html>
<html>
<head>
    <title>Contact Form Message</title>
</head>
<body>
    <h1>Contact Form Message</h1>
    <p><strong>Name:</strong> <?php echo e($data['name']); ?></p>
    <p><strong>Phone:</strong> <?php echo e($data['phone']); ?></p>
    <p><strong>Email:</strong> <?php echo e($data['email']); ?></p>
    <p><strong>Message:</strong> <?php echo e($data['message']); ?></p>
</body>
</html>
<?php /**PATH C:\laragon\www\lb_old\resources\views/layouts/contact_form_mail.blade.php ENDPATH**/ ?>