<template>
    <MainVue/>
</template>

<script>
import MainVue from './frontend/layouts/Main.vue';
export default{
  components:{MainVue},
}
</script>