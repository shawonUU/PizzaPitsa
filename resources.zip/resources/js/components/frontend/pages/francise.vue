<template>
    <div>
        <main class="main-wrapper">
        <!-- Start Breadcrumb Area  -->
        <div class="axil-breadcrumb-area">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6 col-md-8">
                        <div class="inner">
                            <ul class="axil-breadcrumb">
                                <li class="axil-breadcrumb-item"><router-link to="/">Home</router-link></li>
                                <li class="separator"></li>
                                <li class="axil-breadcrumb-item active" aria-current="page">Franchise</li>
                            </ul>
                            <h1 class="title">Franchise</h1>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-4">
                        <div class="inner">
                            <div class="bradcrumb-thumb">
                                <img src="https://new.axilthemes.com/demo/template/etrade-rtl/assets/images/product/product-45.png" alt="Image">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Breadcrumb Area  -->

        <!-- Start About Area  -->
        <div class="axil-about-area about-style-2">
            <div class="container">
                <div class="row align-items-center mb--80 mb_sm--60">                   
                    <div class="col-lg-7 m-auto">
                        <div class="about-content content-right">                                                     
                            <p class="text-heading">At Pizzapitsa ,we value high-quality ingredients. And that doesn’t just apply to our delicious pizza. Our dedication to excellence also means we are looking for Franchise Partners who have strong business acumen and restaurant or hospitality management experience. We are searching for like-minded entrepreneurs that lead with integrity, goodwill, fun, and most importantly - passion. See our available territories now.</p>
                            <router-link to="/contact" class="axil-btn btn-outline">Get In Touch</router-link>
                        </div>
                    </div>
                </div>            
            </div>
        </div>
        <!-- End About Area  -->
    </main>
    </div>
</template>